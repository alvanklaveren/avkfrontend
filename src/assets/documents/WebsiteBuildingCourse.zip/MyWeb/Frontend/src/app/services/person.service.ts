import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Person } from '../model/person';

@Injectable({
  providedIn: 'root'
})

export class PersonService {

  constructor(private http: HttpClient) { }

  getCities(){
    return this.http.post(environment.apiUrl + '/person/getCities', { });
  }

  getPersons(){
    return this.http.post(environment.apiUrl + '/person/getPersons', { });
  }

  getPerson(id: number){
    return this.http.post(environment.apiUrl + '/person/getPerson', id);
  }

  savePerson(person: Person){
    return this.http.post(environment.apiUrl + '/person/savePerson', person);
  }

  deletePerson(id: number){
    return this.http.post(environment.apiUrl + '/person/deletePerson', id);
  }

}