import { City } from './city';

export class Person {
    id?: number;
    name: string;
    street: string;
    postalCode: string;
    
    version?: number;

    city: City;
    
  }