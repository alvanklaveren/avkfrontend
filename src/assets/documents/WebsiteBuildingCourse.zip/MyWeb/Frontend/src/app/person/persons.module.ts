import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { PersonModalComponent } from './modal/personmodal.component';
import { PersonDetailComponent } from './details/persondetail.component';
import { PersonsComponent } from './persons.component';

@NgModule({
  declarations: [
    PersonsComponent,
    PersonDetailComponent,
    PersonModalComponent,

  ],
  imports: [
    SharedModule,
  ],
  providers: [],
  bootstrap: [PersonModalComponent ]

})

export class PersonModule { }
