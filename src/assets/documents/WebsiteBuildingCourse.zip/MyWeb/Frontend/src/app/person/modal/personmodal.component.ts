import {Component, Input, OnInit} from '@angular/core';
import {NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { PersonService } from 'src/app/services/person.service';
import { Person } from 'src/app/model/person';
import { City } from 'src/app/model/city';

@Component({
  selector: 'app-person-modal',
  templateUrl: './personmodal.component.html',
  styleUrls: ['./personmodal.component.scss'],
})

export class PersonModalComponent implements OnInit{

    @Input('person') person: Person;

    persons: Array<Person> = [];
    editForm: FormGroup;
    askDelete = false;

    cities: Array<City> = [];

    constructor(private ngbModal: NgbModal, private activeModal: NgbActiveModal,
                private formBuilder: FormBuilder, private personService: PersonService) { }

    ngOnInit(){

        this.personService.getCities().subscribe(response => {
            this.cities = response as Array<City>;
        });

        this.personService.getPersons().subscribe(response => {
            this.persons = response as Array<Person>;
        });

        this.editForm = this.formBuilder.group({
            name: [null, Validators.required],
            street: [null, Validators.required],
            postalCode: [null, Validators.required],
            cityId: [null, Validators.required],
        });

        if (this.person) {
            this.editForm.patchValue({
                name: this.person.name,
                street: this.person.street,
                postalCode: this.person.postalCode,
                cityId: this.person.city.id,
            });

        } else {
        }
    }

    onDelete(){       
        if(!this.person || !this.person.id) { 
            return;
        }

        this.askDelete = false;
        
        this.personService.deletePerson(this.person.id).subscribe(res => {
            this.activeModal.dismiss("Deleted")
         }, (err) => {
            console.log("Delete failed");
         });
    }

    onSave(){
        let ef = this.editForm.value;

        let person: Person;
        if(this.person){
            person = this.person;
        } else {
            person = new Person();
        }
        
        let city = this.cities.find(c => c.id === Number(ef.cityId));
        console.log(this.cities);
        console.log(ef.cityId);
        console.log(city);


        person.name = ef.name;
        person.street = ef.street;
        person.postalCode = ef.postalCode;
        person.city = city;

        console.log(person);

        this.personService.savePerson(person).subscribe(response => {
            this.person = response as Person;
            this.activeModal.close();
        },(err) => {
            console.log("Saving failed");
        });

    }

    onDismiss() {
        this.activeModal.dismiss('Dismissed!');
    }
  
    onClose() {
        this.activeModal.dismiss('Close!');
    }
  }
