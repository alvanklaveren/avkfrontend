import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { Person} from '../model/person';
import { PersonService } from '../services/person.service';
import { PersonModalComponent } from './modal/personmodal.component';


@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.css']
})
export class PersonsComponent implements OnInit {

  persons: Array<Person> = [];

  constructor(  private router:Router, 
                private route: ActivatedRoute, 
                private ngbModal: NgbModal,
                private personService: PersonService,
                ) { }

  ngOnInit(): void {
    this.personService.getPersons().subscribe(response => {
      this.persons = response as Array<Person>;
    });
    

  }

  openPersonDetails(person: Person){
    this.router.navigateByUrl('/person/' + person.id);
  }

  openPersonModal(){
    let modal = this.ngbModal.open(PersonModalComponent, {ariaLabelledBy: 'app-person-modal'});

    modal.result.then((result) => {
      window.location.reload();
      
    }, (reason) => {
      if(reason === 'Deleted') {
        window.location.reload();
      }
    });

  };

}
