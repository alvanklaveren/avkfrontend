import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { PersonModalComponent } from '../modal/personmodal.component';
import { PersonService } from 'src/app/services/person.service';
import { Person } from 'src/app/model/person';

@Component({
  selector: 'app-persondetail',
  templateUrl: './persondetail.component.html',
  styleUrls: ['./persondetail.component.css']
})
export class PersonDetailComponent implements OnInit {

  constructor(private router:Router, private route: ActivatedRoute, private ngbModal: NgbModal,
              private personService: PersonService,  ) { }

  personId: number;
  person: Person;

  ngOnInit(): void {

    this.personId = this.toNumber(this.route.snapshot.paramMap.get('id'));

    this.personService.getPerson(this.personId).subscribe(response => {
      this.person = response as Person;
    });
  }

  public toNumber(text: string){
    if(isNaN(Number(text))){
      return undefined;
    } 
    return Number(text);
  }

  openPersonModal(person?){
    let modal = this.ngbModal.open(PersonModalComponent, {ariaLabelledBy: 'app-person-modal'});

    if(person) {
      modal.componentInstance.person = person;
    }

    modal.result.then((result) => {    
    }, (reason) => {
      if(reason === 'Deleted') {
        this.router.navigateByUrl('/persons');
      }
    });

  };

}
