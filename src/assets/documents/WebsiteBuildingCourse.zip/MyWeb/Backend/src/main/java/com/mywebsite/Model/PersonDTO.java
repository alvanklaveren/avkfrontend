package com.mywebsite.Model;

import java.util.List;
import java.util.stream.Collectors;

public class PersonDTO {
    public Long id;
    public String name;
    public String street;
    public String postalCode;
    public CityDTO city;
    public Integer version;

    public PersonDTO(){}

    public static List<PersonDTO> toDto(List<Person> persons){
        return persons.stream().map(PersonDTO::toDto).collect(Collectors.toList());
    }

    public static PersonDTO toDto(Person person){
        PersonDTO personDTO = new PersonDTO();

        personDTO.id = person.getId();
        personDTO.name = person.getName();
        personDTO.street = person.getStreet();
        personDTO.postalCode = person.getPostalCode();
        personDTO.city = CityDTO.toDto(person.getCity());
        personDTO.version = person.getVersion();
        return personDTO;
    }

    public String toString() {
        return "Person: id=" + id + ", street='" + street + ", postal code='" + postalCode + ", city=" + city.name;
    }
}
