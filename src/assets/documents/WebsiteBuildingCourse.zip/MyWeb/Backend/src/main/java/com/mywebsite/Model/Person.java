package com.mywebsite.Model;

import javax.persistence.*;

@Entity
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String street;
    private String postalCode;

    @ManyToOne
    @JoinColumn(name = "city_id", nullable = true)
    private City city;

    @Version
    private Integer version;

    public Person() {
    }

    public Person(String name, String street, String postalCode, City city) {
        this.name = name;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
    }

    public Long getId () {
        return id;
    }

    public void setId (Long id){
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "Person: id=" + id + ", street='" + street + ", postal code='" + postalCode + ", city=" + city.getName();
    }
}
