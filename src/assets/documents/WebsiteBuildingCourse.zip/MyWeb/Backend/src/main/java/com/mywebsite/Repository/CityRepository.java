package com.mywebsite.Repository;

import com.mywebsite.Model.City;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CityRepository extends CrudRepository<City, Long> {

    List<City> findAll();
    City getById(Long id);
}