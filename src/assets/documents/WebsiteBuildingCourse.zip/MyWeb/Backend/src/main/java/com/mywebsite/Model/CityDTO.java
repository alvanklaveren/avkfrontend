package com.mywebsite.Model;

import java.util.List;
import java.util.stream.Collectors;

public class CityDTO {
    public Long id;
    public String name;
    public Integer version;

    public CityDTO(){}

    public static List<CityDTO> toDto(List<City> cities){
        return cities.stream().map(CityDTO::toDto).collect(Collectors.toList());
    }

    public static CityDTO toDto(City city){
        CityDTO cityDTO = new CityDTO();
        cityDTO.id = city.getId();
        cityDTO.name = city.getName();
        cityDTO.version = city.getVersion();
        return cityDTO;
    }

    @Override
    public String toString(){ return "City: " + id + " " + name; }
}