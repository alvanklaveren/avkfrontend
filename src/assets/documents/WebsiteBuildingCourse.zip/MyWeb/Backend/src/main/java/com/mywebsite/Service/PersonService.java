package com.mywebsite.Service;

import com.mywebsite.Model.CityDTO;
import com.mywebsite.Model.PersonDTO;
import com.mywebsite.UseCase.PersonUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/person")
public class PersonService {

    @Autowired private PersonUseCase personUseCase;


    @CrossOrigin @RequestMapping("/getCities")
    public ResponseEntity<List<CityDTO>> getCities(){

        List<CityDTO> cityDTOs = personUseCase.getCities();
        return new ResponseEntity<>(cityDTOs, HttpStatus.OK);
    }

    @CrossOrigin @RequestMapping("/getPersons")
    public ResponseEntity<List<PersonDTO>> getPersons(){

        List<PersonDTO> personDTOs = personUseCase.getPersons();
        return new ResponseEntity<>(personDTOs, HttpStatus.OK);
    }

    @CrossOrigin @RequestMapping("/getPerson")
    public ResponseEntity<PersonDTO> getPerson(@RequestBody Long id){

        PersonDTO personDTO = personUseCase.getPerson(id);
        return new ResponseEntity<>(personDTO, HttpStatus.OK);
    }

    @CrossOrigin @RequestMapping("/deletePerson")
    public ResponseEntity<String> deletePerson(@RequestBody Long id){

        personUseCase.deletePerson(id);
        return new ResponseEntity<>("", HttpStatus.OK);
    }

    @CrossOrigin @RequestMapping("/savePerson")
    public ResponseEntity<PersonDTO> save(@RequestBody PersonDTO personDTO){

        personDTO = personUseCase.save(personDTO);
        return new ResponseEntity<>(personDTO, HttpStatus.OK);
    }

}
