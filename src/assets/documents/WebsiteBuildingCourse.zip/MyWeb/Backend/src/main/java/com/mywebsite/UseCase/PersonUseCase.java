package com.mywebsite.UseCase;

import com.mywebsite.Model.City;
import com.mywebsite.Model.CityDTO;
import com.mywebsite.Model.Person;
import com.mywebsite.Model.PersonDTO;
import com.mywebsite.Repository.CityRepository;
import com.mywebsite.Repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;

@Component
public class PersonUseCase {
    @Autowired CityRepository cityRepository;
    @Autowired PersonRepository personRepository;


    @Transactional
    public List<CityDTO> getCities(){
        List<City> cities = cityRepository.findAll();
        return CityDTO.toDto(cities);
    }

    @Transactional
    public List<PersonDTO> getPersons(){
        List<Person> persons = personRepository.findAll();
        return PersonDTO.toDto(persons);
    }

    @Transactional
    public PersonDTO getPerson(Long id){
        Person person = personRepository.findById(id).orElse(null);
        if(person == null){
            throw new RuntimeException("Person with id=" + id + " does not exist in database");
        }

        return PersonDTO.toDto(person);
    }

    @Transactional
    public void deletePerson(Long id){
        Person person = personRepository.findById(id).orElse(null);
        if(person == null){
            throw new RuntimeException("Person with id=" + id + " does not exist in database");
        }
        personRepository.delete(person);
    }

    @Transactional
    public PersonDTO save(PersonDTO personDTO){

        Person person = personDTO.id == null ? null : personRepository.findById(personDTO.id).orElse(null);
        if(person == null){
            person = new Person();
        }

        person.setName(personDTO.name);
        person.setStreet(personDTO.street);
        person.setPostalCode(personDTO.postalCode);
        person.setVersion(personDTO.version);

        City city = personDTO.city != null ? cityRepository.getById(personDTO.city.id) : null;
        person.setCity(city);

        person = personRepository.save(person);

        return PersonDTO.toDto(person);
    }
}
